package com.dunctebot.dashboard.constants

object ContentType {
    const val JSON = "application/json"
    const val HTML = "text/html"
}
