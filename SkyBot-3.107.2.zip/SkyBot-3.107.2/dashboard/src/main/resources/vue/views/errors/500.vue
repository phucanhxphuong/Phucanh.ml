<template id="error-500">
    <div class="center">
        <h4>Internal server error.</h4>
        <h6>Please contact the developers on <a href="https://duncte.bot/discord" target="_blank">discord</a></h6>
    </div>
</template>

<script>
Vue.component('error-500', {
    template: '#error-500',
});
</script>
