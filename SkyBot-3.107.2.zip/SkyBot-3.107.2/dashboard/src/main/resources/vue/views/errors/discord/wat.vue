<template id="error-wat">
    <div>
        <h1 class="center">
            WAT?!
        </h1>

        <h4 class="center">
            Either discord did a fucky wucky or you are not in the server that you are trying to edit
        </h4>
    </div>
</template>

<script>
Vue.component('error-discord-wat', {
    template: '#error-wat',
});
</script>
