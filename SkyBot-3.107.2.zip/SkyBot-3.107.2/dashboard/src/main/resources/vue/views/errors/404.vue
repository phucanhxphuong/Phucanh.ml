<template id="error-404">
    <div>
        <h1 class="center">404 :(</h1>
        <h4 class="center">The requested page was not found on this server.</h4>
    </div>
</template>

<script>
    Vue.component('error-404', {
        template: '#error-404',
    });
</script>
