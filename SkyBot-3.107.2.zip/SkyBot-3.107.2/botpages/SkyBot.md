

DuncteBot is a bot with a lot of features like mod commands.

If you require any support, please join our [Discord server][guild]

## List of commands
The list with commands can be found on [our website][commandList] ([https://duncte.bot/commands][commandList])


## The join and leave messages use a special notation
    
The documentation can be found here: [https://github.com/DuncteBot/SkyBot/wiki/JagTag](https://github.com/DuncteBot/SkyBot/wiki/JagTag)


If you don't want the bot to respond to commands in a certain channel make sure to add `-commands` to the channel topic.

[guild]: https://duncte.bot/server
[commandList]: https://duncte.bot/commands
